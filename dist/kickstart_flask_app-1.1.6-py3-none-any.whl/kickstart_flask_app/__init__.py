#!/usr/bin/python
# -*- coding: utf-8 -*-
from .core import (KickstartFlaskApp, console)

__all__ = (
    'KickstartFlaskApp',
    'console',
)