# kickstart-flask-app

This is a simple package to kickstart a new Flask app project
[kickstart-flask-app](https://github.com/MurphyAdam/kickstart-flask-app)