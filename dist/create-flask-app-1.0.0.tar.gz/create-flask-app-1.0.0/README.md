# create-flask-app

This is a simple package to kickstart a new Flask app project
[create-flask-app](https://github.com/MurphyAdam/create-flask-app)